const inputs=[...document.querySelectorAll(".otp input")];
const message=document.getElementById("message");
const resend=document.getElementById("resend");

/*
  DEMO VERIFICATION
  Change this value to your own 4-digit code.
  For real OTP/email/SMS verification, validate the code on a server.
*/
const ACCESS_CODE="1234";
let verifying=false;

inputs.forEach((input,index)=>{
  input.addEventListener("input",()=>{
    input.value=input.value.replace(/\D/g,"").slice(0,1);
    if(input.value && index<inputs.length-1) inputs[index+1].focus();
    if(inputs.every(x=>x.value.length===1)) verify();
  });

  input.addEventListener("keydown",(e)=>{
    if(e.key==="Backspace" && !input.value && index>0){
      inputs[index-1].focus();
    }
    if(e.key==="ArrowLeft" && index>0) inputs[index-1].focus();
    if(e.key==="ArrowRight" && index<inputs.length-1) inputs[index+1].focus();
  });

  input.addEventListener("paste",(e)=>{
    e.preventDefault();
    const code=(e.clipboardData.getData("text")||"").replace(/\D/g,"").slice(0,4);
    code.split("").forEach((n,i)=>{if(inputs[i])inputs[i].value=n});
    if(code.length===4) verify();
  });
});

function verify(){
  if(verifying) return;
  const code=inputs.map(x=>x.value).join("");
  if(code.length!==4) return;

  verifying=true;
  message.textContent="Verifying…";
  inputs.forEach(x=>x.disabled=true);

  setTimeout(()=>{
    if(code===ACCESS_CODE){
      message.textContent="";
      document.getElementById("verifyCard").classList.add("verified");
      window.location.href="verified.html";
    }else{
      message.textContent="Incorrect access code. Please try again.";
      inputs.forEach(x=>{x.value="";x.disabled=false});
      inputs[0].focus();
      verifying=false;
    }
  },900);
}

resend.addEventListener("click",()=>{
  message.style.color="#7462cb";
  message.textContent="Demo code regenerated.";
  setTimeout(()=>message.textContent="",1800);
});
